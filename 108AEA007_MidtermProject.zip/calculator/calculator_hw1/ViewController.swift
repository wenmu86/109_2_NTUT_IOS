//
//  ViewController.swift
//  calculator_hw1
//
//  Created by 108aea007 on 2021/4/30.
//  Copyright © 2021 108aea007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displaylabel: UILabel!
    @IBOutlet weak var displaylabel_1: UILabel!
    private var isTyping = false
    private var isEqual = false //判断是否按等号
    private var DotCount = 0 //判断是否出现小数点
    private var judge = 0
    
    var displayValue: Double{
        get{
            return Double(displaylabel.text!)!
        }
        set {
            if String(newValue) == "inf" {
                displaylabel.text = "0"
            }
            else {
                displaylabel.text = String(newValue)
            }
            isEqual = true
        }
    }

    @IBAction func digitTapped(_ sender: UIButton) {
        let digit = sender.currentTitle!
        if digit == "." {
            DotCount += 1
        }
        
        if digit == "." && DotCount > 1{
        }else if isTyping{
            displaylabel.text! = displaylabel.text! + digit
        }else{
            displaylabel.text = digit
            isTyping = true
        }
    }

    @IBAction func display(_ sender: UIButton) {
        let digit1 = sender.currentTitle!
        
        if digit1 == "." && DotCount > 1{            
        }
        if (digit1 == "+" || digit1 == "-" || digit1 == "×" || digit1 == "÷" || digit1 == "=") && isTyping{
            if judge == 0{
                let a = Double(displaylabel.text!)!
                displaylabel_1.text! = String(a) + digit1
                judge = 1
            }
            else {
                let a = Double(displaylabel.text!)!
                displaylabel_1.text! =  displaylabel_1.text! + String(a) + digit1
            }
        }
        if isEqual {
            let a = Double(displaylabel.text!)!
            displaylabel_1.text! =   String(a) + digit1
            isEqual = false
        }
    }
    
    @IBAction func acTapped(_ sender: UIButton) {
        displaylabel.text = "0"
        displaylabel_1.text = ""
        isTyping = false
        isEqual = false
        DotCount = 0
    }
    
    var brain = CalculatorBrain()
    
    @IBAction func operationTapped(_ sender: UIButton) {
        if isTyping{
            brain.setOperand(displayValue)
            isTyping = false
            DotCount = 0
        }
        
        brain.performOperation(sender.currentTitle!)
        
        if let result = brain.result{
            displayValue = result
        }
    }
    
    @IBAction func percent(_ sender: Any) {
        let count = Double(displaylabel.text!)!
        let count2 = count * 0.01
        displaylabel.text = String(count2)
    }
    
}

