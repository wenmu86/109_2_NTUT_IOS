//
//  CalculatorBrain.swift
//  calculator_hw1
//
//  Created by 108aea007 on 2021/4/30.
//  Copyright © 2021 108aea007. All rights reserved.
//

import Foundation
struct CalculatorBrain {
    
    enum Operation{
        case unary((Double) -> Double)
        case binary((Double,Double) -> Double)
        case equals
    }
    private var equalCount = 0
    
    private let operations: [String: Operation] = [
        "±": .unary(-),
        "√": .unary(sqrt),
        "+": .binary(+),
        "-": .binary(-),
        "×": .binary(*),
        "÷": .binary(/),
        "=": .equals
    ]
    
    private var accumulator: Double?
    
   mutating func setOperand(_ operand: Double){
        accumulator = operand
    }

    var result: Double?{
        return accumulator
    }
    
    mutating func performOperation(_ symbol: String){
        let operation = operations[symbol]!
        
        switch operation {
        case .unary(let function):
            if let operand = accumulator{
                accumulator = function(operand)
                equalCount = 0
            }
        case .binary(let function):
            if let firstOprand = accumulator{
                pendingBinaryOperation = PendingBinaryOperation(function: function,firstOperand: firstOprand)
                accumulator = nil
                equalCount = 0
            }
        case .equals:
            if let operation = pendingBinaryOperation, let secondOperand = accumulator, equalCount == 0{
                accumulator = operation.perform(with: secondOperand)
                equalCount = 1
            }
        }
    }
    
    private var pendingBinaryOperation: PendingBinaryOperation?
    
    private struct PendingBinaryOperation {
        let function:(Double,Double) -> Double
        let firstOperand: Double
        
        func perform(with secondOperand: Double) -> Double{
            return function(firstOperand,secondOperand)
        }
          
    }
}
