//
//  GameResult.swift
//  file
//
//  Created by liurong on 2021/5/25.
//

import Foundation
enum GameResult {
    case win
    case lose
    case tie
    case defaultR
}
