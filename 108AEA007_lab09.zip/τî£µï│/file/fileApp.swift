//
//  fileApp.swift
//  file
//
//  Created by liurong on 2021/5/3.
//

import SwiftUI

@main
struct fileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
