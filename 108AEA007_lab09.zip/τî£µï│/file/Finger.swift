//
//  Finger.swift
//  file
//
//  Created by liurong on 2021/5/25.
//

import SwiftUI

struct Finger {
    let suit: Suit
    
    enum Suit: String, CaseIterable {
        case rock = "👊"
        case paper = "🖐"
        case scissors = "✌️"
    }
    
}

