//
//  ContentView.swift
//  file
//
//  Created by liurong on 2021/5/3.
//

import SwiftUI
struct ContentView: View {
    @StateObject var gameViewModel = GameViewModel()
    var body: some View {
        VStack {
            Text("猜拳遊戲").font(.largeTitle)
            HStack{
                Text("玩家")
                Text(gameViewModel.playerFinger?.suit.rawValue ?? "👊")
                
                
            } .font(.system(size: 30))
            Image("san")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 190)
                .shadow(radius: 20)
            HStack{
                Text("電腦")
                Text(gameViewModel.computerFinger?.suit.rawValue ?? "👊")
            } .font(.system(size: 50))
            if let result = gameViewModel.result {
                Text(result == .win ? "你贏了！" : "你輸了！" )
                    .font(.system(size: 50))
            }
            Button(action: {
                gameViewModel.play()
            }, label: {
                Text("start！")
            }).font(.title3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

    
