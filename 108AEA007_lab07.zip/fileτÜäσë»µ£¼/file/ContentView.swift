//
//  ContentView.swift
//  file
//
//  Created by liurong on 2021/5/3.
//

import SwiftUI
struct ContentView: View {
    @State private var showSecondPage = false
    @State private var showStory = false
    
    var body: some View {
        
        VStack(alignment: .center) {
            
            Image("1")
                .resizable()
                .scaledToFit()
                .frame(width: 300, height: 400)
                .shadow(radius: 20)
            
            Button(action: {
                showSecondPage = true
            }, label: {
                Text("作者")
            })
            .fullScreenCover(isPresented: $showSecondPage, content: {SwiftUIView(showSecondPage: $showSecondPage)}
            )
            
            Button(action: {
                showStory = true
            }, label: {
                Text("劇情")
            })
            .fullScreenCover(isPresented: $showStory, content: {story(showStory: $showStory)}
            )
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

    
