//
//  story.swift
//  file
//
//  Created by liurong on 2021/5/11.
//

import SwiftUI

struct story: View {
    @Binding var showStory: Bool
    
    let storys = ["《櫻桃小丸子》（日語：ちびまる子ちゃん）是已故日本漫畫家櫻桃子創作的日本漫畫作品。於1986年在少女漫畫雜誌《Ribon》開始連載，單行本全17冊[1]，後來改編成動畫、遊戲、電視劇。故事描敘小丸子以及其家人和同學展開，有關於親情、友誼或是一些生活事情，令人回想起童年的稚氣。"]
    var body: some View {
        Image("1")
            .resizable()
            .scaledToFit()
            .frame(width: 300, height: 400)
            .shadow(radius: 20)
        ZStack(alignment: .center) {
            Color.white
                .edgesIgnoringSafeArea(.all)
            VStack{
                ForEach(storys.indices) { index in
                    Text(storys[index])
                }
            }
        }
        .overlay(
            Button(action: {
                showStory = false
            }, label: {
                Image(systemName: "xmark.circle.fill")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .padding(20)
            }), alignment: .topTrailing)
    }
}

struct story_Previews: PreviewProvider {
    static var previews: some View {
        story(showStory: .constant(true))
    }
}
