//
//  SwiftUIView.swift
//  file
//
//  Created by liurong on 2021/5/3.
//

import SwiftUI


struct SwiftUIView: View {
    @Binding var showSecondPage: Bool
    let authors = ["櫻桃子（日語：さくら ももこ，1965年5月8日－2018年8月15日），日本女漫畫家、作家，出生於靜岡縣清水市（現為靜岡縣靜岡市清水區），家中經營蔬果店。1984年正式出道後，1986年以筆名「櫻桃子」行，以童年時期的經歷為藍本開始繪畫漫畫《櫻桃小丸子》，主角的名字也是櫻桃子、主角的生日也是櫻桃子的生日。櫻桃子生動、詼諧的寫作手法，令《櫻桃小丸子》在日本及日本以外的亞洲地區都受到歡迎。"]
    var body: some View {
        ZStack {
            Color.white
                .edgesIgnoringSafeArea(.all)
            Image("1")
                .resizable()
                .scaledToFit()
                .frame(width: 300, height: 400)
                .shadow(radius: 20)
            VStack{
                Image("anben")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 400)
                    .shadow(radius: 20)
                
                ForEach(authors.indices) { index in
                    Text(authors[index])
                }
            }
            
        }.overlay(
                Button(action: {
                    showSecondPage = false
                }, label: {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding(20)

                }), alignment: .topTrailing)
        }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView(showSecondPage: .constant(true))
    }
}
